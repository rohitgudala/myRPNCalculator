package com.rohit.calc.userentry.operation;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.math.BigDecimal;

import org.junit.Test;

import com.rohit.calc.userentry.CheckAndStoreValue;

public class DivisionTest {

	/**
	 * Given 2 numbers in the store When the Division Cons called The store will
	 * update the result
	 */
	@Test
	public void when2ElementsProvidedThenStoreUpdateWithOneResult() {
		// Given 2 elements in the storage
		CheckAndStoreValue store = new CheckAndStoreValue();
		store.getNumberStack().push(new BigDecimal("10"));
		store.getNumberStack().push(new BigDecimal("2"));
		BigDecimal result = new Division(store).getResultValue();
		assertNotNull(result);
		assertEquals(new BigDecimal("5.000"), result);
	}

	/**
	 * Given 2 negative in the store When the Division Cons called The store will
	 * update the result
	 */
	@Test
	public void when2NegitiveElementsProvidedThenStoreUpdateWithOneResult() {
		// Given 2 elements in the storage
		CheckAndStoreValue store = new CheckAndStoreValue();
		store.getNumberStack().push(new BigDecimal("-2"));
		store.getNumberStack().push(new BigDecimal("-10"));
		BigDecimal result = new Division(store).getResultValue();
		assertNotNull(result);
		assertEquals(new BigDecimal("0.200"), result);
	}

	/**
	 * Given 2 negative in the store When the Division Cons called The store will
	 * update the result
	 */
	@Test
	public void whenaPositiveAndNegativeElementsProvidedThenStoreUpdateWithOneResult() {
		// Given 2 elements in the storage
		CheckAndStoreValue store = new CheckAndStoreValue();
		store.getNumberStack().push(new BigDecimal("-2"));
		store.getNumberStack().push(new BigDecimal("10"));
		BigDecimal result = new Division(store).getResultValue();
		assertNotNull(result);
		assertEquals(new BigDecimal("-0.200"), result);
	}

}
