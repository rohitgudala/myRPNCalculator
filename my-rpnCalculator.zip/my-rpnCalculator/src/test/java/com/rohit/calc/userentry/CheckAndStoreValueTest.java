package com.rohit.calc.userentry;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.rohit.calc.Operations.OperatorsEnum;

public class CheckAndStoreValueTest {

	private CheckAndStoreValue testInstance;

	@Before
	public void setUp() {
		this.testInstance = new CheckAndStoreValue();
	}

	@After
	public void tearDown() {
		this.testInstance = null;
	}

	/**
	 * Given a null string when the checkandinsert method called Then an Exception
	 * will raised
	 */
	@Test
	public void whenNullStringProvidedThenIllegalArgumentExceptionWillRaised() {
		String userEntered = null;
		try {
			testInstance.checkAndInsert(userEntered);
		} catch (Exception e) {
			// Then an IllegalArgumentException raised
			assertTrue(e instanceof IllegalArgumentException);
			assertEquals(e.getMessage(), "Not a valid input");
		}
	}

	/**
	 * Given a valid number when the checkandinsert method called Then the value
	 * should be populated in number stack
	 * @throws Exception 
	 */
	@Test
	public void whenValidNumberProvidedThenNumberStackShouldBePopulated() throws Exception {
		String userEntered = "6";
		testInstance.checkAndInsert(userEntered);
		assertEquals(testInstance.getNumberStack().size(), 1);
		assertEquals(testInstance.getNumberStack().pop(), new BigDecimal(userEntered));
	}
	
	/**
	 * Given a valid operator when the checkandinsert method called Then the value
	 * should be populated in operator stack
	 * @throws Exception 
	 */
	@Test
	public void whenValidOperatorAdditionProvidedThenNumberStackShouldBePopulated() throws Exception {
		String userEntered = "+";
		testInstance.checkAndInsert(userEntered);
		assertEquals(testInstance.getOperatorStack().size(), 1);
		assertEquals(testInstance.getOperatorStack().pop(), OperatorsEnum.ADDITION);
	}
	
	/**
	 * Given a valid operator when the checkandinsert method called Then the value
	 * should be populated in operator stack
	 * @throws Exception 
	 */
	@Test
	public void whenValidOperatorSubProvidedThenNumberStackShouldBePopulated() throws Exception {
		String userEntered = "-";
		testInstance.checkAndInsert(userEntered);
		assertEquals(testInstance.getOperatorStack().size(), 1);
		assertEquals(testInstance.getOperatorStack().pop(), OperatorsEnum.SUBTRACTION);
	}
	
	/**
	 * Given a valid operator when the checkandinsert method called Then the value
	 * should be populated in operator stack
	 * @throws Exception 
	 */
	@Test
	public void whenValidOperatorMultiplyProvidedThenNumberStackShouldBePopulated() throws Exception {
		String userEntered = "*";
		testInstance.checkAndInsert(userEntered);
		assertEquals(testInstance.getOperatorStack().size(), 1);
		assertEquals(testInstance.getOperatorStack().pop(), OperatorsEnum.MULTIPLICATION);
	}
	
	/**
	 * Given a valid operator when the checkandinsert method called Then the value
	 * should be populated in operator stack
	 * @throws Exception 
	 */
	@Test
	public void whenValidOperatorDivisonProvidedThenNumberStackShouldBePopulated() throws Exception {
		String userEntered = "/";
		testInstance.checkAndInsert(userEntered);
		assertEquals(testInstance.getOperatorStack().size(), 1);
		assertEquals(testInstance.getOperatorStack().pop(), OperatorsEnum.DIVISION);
	}
	
	
	/**
	 * Given a valid operator when the checkandinsert method called Then the value
	 * should be populated in operator stack
	 * @throws Exception 
	 */
	@Test
	public void whenalphabetProvidedThenIllegalArgumentExceptionIsRaised()  {
		String userEntered = "P";
		try {
			testInstance.checkAndInsert(userEntered);
		} catch (Exception e) {
			// Then an IllegalArgumentException raised
			assertTrue(e instanceof IllegalArgumentException);
			assertEquals(e.getMessage(), "Not a valid input");
		}
	}

}
