package com.rohit.calc.Operations;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.Test;

public class OperatorsEnumTest {

	/**
	 * Given a null string when the fromString method called Then an
	 * IllegalArgumentException ShouldBe raised
	 */
	@Test
	public void whenNullStringProvidedThenIllegalArgumentExceptionShouldBeRaised() {
		String userInput = null;
		try {
			OperatorsEnum.fromString(userInput);
			fail("Program reached unexpected point");
		} catch (Exception e) {
			// Then an IllegalArgumentException raised
			assertTrue(e instanceof IllegalArgumentException);
		}
	}

	/**
	 * Given an empty string when the fromString method called Then an
	 * IllegalArgumentException ShouldBe raised
	 */
	@Test
	public void whenAnEmptyStringProvidedThenIllegalArgumentExceptionShouldBeRaised() {
		String userInput = "";
		try {
			OperatorsEnum.fromString(userInput);
			fail("Program reached unexpected point");
		} catch (Exception e) {
			// Then an IllegalArgumentException raised
			assertTrue(e instanceof IllegalArgumentException);
		}
	}

	/**
	 * Given an invalid string when the fromString method called Then an
	 * IllegalArgumentException ShouldBe raised
	 */
	@Test
	public void whenAnInvalidStringProvidedThenIllegalArgumentExceptionShouldBeRaised() {
		String userInput = "abc";
		try {
			OperatorsEnum.fromString(userInput);
			fail("Program reached unexpected point");
		} catch (Exception e) {
			assertTrue(e instanceof IllegalArgumentException);
		}
	}

	/**
	 * Given an addition string when the fromString method called Then an addition
	 * operator ShouldBe returned
	 */
	@Test
	public void whenAnAdditionStringProvidedThenAnAdditionOperatorShouldReturn() {
		String userInput = "+";
		OperatorsEnum operator = OperatorsEnum.fromString(userInput);
		assertTrue(OperatorsEnum.ADDITION == operator);
	}

	/**
	 * Given a subtraction string when the fromString method called Then a
	 * subtraction operator ShouldBe returned
	 */
	@Test
	public void whenAsubtractionStringProvidedThenASubtractionOperatorShouldReturn() {
		String userInput = "-";
		OperatorsEnum operator = OperatorsEnum.fromString(userInput);
		assertTrue(OperatorsEnum.SUBTRACTION == operator);
	}

	/**
	 * Given a Multiplication string when the fromString method called Then a
	 * Multiplication operator ShouldBe returned
	 */
	@Test
	public void whenAMultiplicationStringProvidedThenAMultiplicationOperatorShouldReturn() {
		String userInput = "*";
		OperatorsEnum operator = OperatorsEnum.fromString(userInput);
		assertTrue(OperatorsEnum.MULTIPLICATION == operator);
	}

	/**
	 * Given a Division string when the fromString method called Then a Division
	 * operator ShouldBe returned
	 */
	@Test
	public void whenADivisionStringProvidedThenADivisionOperatorShouldReturn() {
		String userInput = "/";
		OperatorsEnum operator = OperatorsEnum.fromString(userInput);
		assertTrue(OperatorsEnum.DIVISION == operator);
	}

}
