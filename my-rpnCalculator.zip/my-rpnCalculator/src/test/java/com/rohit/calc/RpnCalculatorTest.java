package com.rohit.calc;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.FileInputStream;
import java.io.InputStream;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Unit test for RpnCalculator App.
 */
public class RpnCalculatorTest {
	private RPNCalculator rpnCalc;

	/**
	 * Rigorous Test
	 */
	@Before
	public void setUp() {
		this.rpnCalc = new RPNCalculator();
	}

	@After
	public void tearDown() {
		this.rpnCalc = null;
	}

	/**
	 * Given a null input stream and called the RPNCalculator
	 * IllegalArgumentException raised
	 */
	@Test
	public void whenNullInputStreamGivenThenAnIllegalArgumentExceptionRaised() {
		InputStream in = null;
		try {
			new RPNCalculator(in);
		} catch (IllegalArgumentException e) {
			String message = e.getMessage();
			assertNotNull(message);
			assertEquals("User input stream cannot be null", message);
		}
	}

	/**
	 * Given an input stream called A RPNCalculator object should return
	 * 
	 * @throws Throwable
	 */
	@Test
	public void whenAnInputStreamProvidedThenARpnCalculatorObjectShouldReturn() throws Throwable {
		InputStream in = new FileInputStream("src/test/resources/sampletest.properties");
		RPNCalculator rpnCalculator = new RPNCalculator(in);
		assertNotNull(rpnCalculator);
	}

	/**
	 * Given user can access to RPNCalculator class When the default constructor
	 * called A RPNCalculator object should return
	 * 
	 * @throws Throwable
	 */
	@Test
	public void whenNoInputStreamProvidedThenARpnCalculatorObjectShouldReturn() throws Throwable {
		RPNCalculator rpnCalculator = new RPNCalculator();
		assertNotNull(rpnCalculator);
	}

	/**
	 * Given input value is an operator and to check whether the operator stack is
	 * being populated ot not called A RPNCalculator object should return
	 * 
	 * @throws Throwable
	 *//*
		 * @Test public void whenAdditionOperatorisFirstUserInput() throws Throwable {
		 * RPNCalculator rpnCalculator = new RPNCalculator();
		 * rpnCalculator.calculator(); assertNotNull(rpnCalculator.getStore()); }
		 */

}
