package com.rohit.calc;

import java.io.InputStream;
import java.math.BigDecimal;
import java.util.Scanner;

import com.rohit.calc.userentry.CheckAndStoreValue;
import com.rohit.calc.userentry.operatorAssigner.Operator;

public class RPNCalculator {

	static BigDecimal result = null;

	private static CheckAndStoreValue store = new CheckAndStoreValue();

	private Scanner inputScanner;

	private static Operator operatorAssigner = new Operator();

	public RPNCalculator() {
		this(System.in);
	}

	public RPNCalculator(InputStream userInput) {
		if (null == userInput) {
			throw new IllegalArgumentException("User input stream cannot be null");
		}
	}

	public void calculator() {

		try {

			String userEnteredvalue = "";
			while (!"q".equalsIgnoreCase(userEnteredvalue)) {

				inputScanner = new Scanner(System.in);

				userEnteredvalue = inputScanner.nextLine();
				if (!"U+0004".equalsIgnoreCase(userEnteredvalue)) {
					String userValues[] = userEnteredvalue.trim().split(" ");
					for (String segregatedValue : userValues) {
						try {
							store.checkAndInsert(segregatedValue);
						} catch (Exception ex) {
							break;
						}
					}

					if (!store.getOperatorStack().empty()) {
						result = operatorAssigner.fetchOperatorAndCalc(store);
					}
					if (result != null) {
						System.out.println(result);
						result = null;
					}
				} else {
					userEnteredvalue = "q";
				}
			}
		} catch (Exception ex) {
			System.out.println("An Abrupt Closure");
		}

	}

	public static void main(String[] args) {
		new RPNCalculator().calculator();
	}

	public Scanner getInputScanner() {
		return inputScanner;
	}

	public static CheckAndStoreValue getStore() {
		return store;
	}

}
