package com.rohit.calc.userentry.operation;

import java.math.BigDecimal;

import com.rohit.calc.userentry.CheckAndStoreValue;

public class Division {

	private BigDecimal resultValue;

	public BigDecimal getResultValue() {
		return resultValue;
	}

	public Division(CheckAndStoreValue store) {
		BigDecimal value1 = store.getNumberStack().pop();
		BigDecimal value2 = store.getNumberStack().pop();
		
		if (BigDecimal.ZERO.equals(value1)) {
			System.err.println("Divisor cannot be ZERO!");
			this.resultValue = new BigDecimal("0");
		}else
		this.resultValue = value2.divide(value1, 3, BigDecimal.ROUND_DOWN);
	}
}
