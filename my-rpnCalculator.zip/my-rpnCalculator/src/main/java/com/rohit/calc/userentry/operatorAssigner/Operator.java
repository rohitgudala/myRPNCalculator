package com.rohit.calc.userentry.operatorAssigner;

import java.math.BigDecimal;
import java.util.Stack;

import com.rohit.calc.Operations.OperatorsEnum;
import com.rohit.calc.userentry.operation.Addition;
import com.rohit.calc.userentry.operation.Division;
import com.rohit.calc.userentry.operation.Multiplication;
import com.rohit.calc.userentry.operation.Subtraction;

public class Operator {

	Stack<BigDecimal> userStack = new Stack<>();

	Stack<OperatorsEnum> operatorStack = new Stack<>();

	static BigDecimal result = null;

	public BigDecimal fetchOperatorAndCalc(com.rohit.calc.userentry.CheckAndStoreValue store) {
		if (store.getNumberStack().size() >= 2) {
			OperatorsEnum operator = store.getOperatorStack().pop();
			switch (operator) {
			case ADDITION:
				result = (new Addition(store).getResultValue());
				extracted(store);
				break;
			case SUBTRACTION:
				result = (new Subtraction(store).getResultValue());
				extracted(store);
				break;
			case MULTIPLICATION:
				result = (new Multiplication(store).getResultValue());
				extracted(store);
				break;
			case DIVISION:
				result = (new Division(store).getResultValue());
				extracted(store);
				break;
			}
		} else {
			System.out.println("Not enough parameters to operate");
		}
		return result;
	}

	private static void extracted(com.rohit.calc.userentry.CheckAndStoreValue store) {
		store.getNumberStack().push(result);
	}

	public Stack<BigDecimal> getUserStack() {
		return userStack;
	}

	public Stack<OperatorsEnum> getOperatorStack() {
		return operatorStack;
	}
}
