package com.rohit.calc.userentry;

import java.math.BigDecimal;
import java.util.Stack;

import com.rohit.calc.Operations.OperatorsEnum;

public class CheckAndStoreValue {

	Stack<BigDecimal> numberStack = new Stack<>();

	Stack<OperatorsEnum> operatorStack = new Stack<>();

	public void checkAndInsert(String value) throws Exception {
		try {
			numberStack.push(new BigDecimal(value));
		} catch (Exception ex) {
			try {
				OperatorsEnum operator = OperatorsEnum.fromString(value);
				operatorStack.push(operator);
			} catch (IllegalArgumentException e) {
				if (!"q".equalsIgnoreCase(value))
					System.err.println("Please enter a valid number/operator");
				throw new IllegalArgumentException("Not a valid input");
			}
		}

	}

	public Stack<BigDecimal> getNumberStack() {
		return numberStack;
	}

	public Stack<OperatorsEnum> getOperatorStack() {
		return operatorStack;
	}
}
