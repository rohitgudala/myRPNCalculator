package com.rohit.calc.userentry.operation;

import java.math.BigDecimal;

import com.rohit.calc.userentry.CheckAndStoreValue;

public class Subtraction {

	private BigDecimal resultValue;

	public BigDecimal getResultValue() {
		return resultValue;
	}

	public Subtraction(CheckAndStoreValue store) {
		BigDecimal value1 = store.getNumberStack().pop();
		BigDecimal value2 = store.getNumberStack().pop();
		this.resultValue = value2.subtract(value1);
	}
}
