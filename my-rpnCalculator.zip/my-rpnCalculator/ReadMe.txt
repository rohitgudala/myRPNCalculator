RPN Calculator Program

As the minimum number of operands required for a basic calculation is two and the order of execution does depend on the latest operator and post calculation no such
scenario of displaying the early results or operators is required I have chosen to use a stack collection with extensive usage of push and pop operation for
developing the RPN calculator program. Have used two stack instance one to store the number input and the other one to store the operator input. 
Every time an operator is pushed into the respective stack corresponding operation should be triggered with the latest two number inputs present in the number stack. 
Have included validation checks for pushing on the data into their corresponding stacks. Exception handlings have been done to cover unwanted scenarios and to proceed 
with the program flow.

For more qualitative coding and easy maintenance , should have been done in a  3 tier architectural way by creating a model for the user input, a business layer with validation and computation logic, and a 
presentation layer with displaying the data for the end-user. Pre scrum calls and few project deliverables hooked me up to complete the program within 3 hours.
And have utilized an extra time to cover most of the JUnit test cases.

It has been implemented in a single-tier architecture as it would be fast for a single user as there is no communication with other system/server and 
taken into consideration the values entered(Database) is equivalent to the data we will be showing to the end-user.


Download the zipped file
Open command prompt
cd path-to-unzipped-file
mvn clean install
java -jar target/my-rpnCalculator-1.0-SNAPSHOT.jar